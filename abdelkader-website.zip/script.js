
function changeLanguage(lang) {
  alert("Multilingual content not yet implemented. You selected: " + lang);
}
